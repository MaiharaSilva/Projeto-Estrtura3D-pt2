var searchData=
[
  ['figurageometrica_0',['FiguraGeometrica',['../class_figura_geometrica.html',1,'']]],
  ['figurageometrica_2eh_1',['FiguraGeometrica.h',['../_figura_geometrica_8h.html',1,'']]]
];
