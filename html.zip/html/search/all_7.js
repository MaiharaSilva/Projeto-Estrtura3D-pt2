var searchData=
[
  ['leitura_0',['Leitura',['../class_leitura.html',1,'Leitura'],['../class_leitura.html#a0546ea401044efc827074dad13867c61',1,'Leitura::Leitura()']]],
  ['leitura_2ecpp_1',['Leitura.cpp',['../_leitura_8cpp.html',1,'']]],
  ['leitura_2eh_2',['Leitura.h',['../_leitura_8h.html',1,'']]]
];
