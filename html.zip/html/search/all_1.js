var searchData=
[
  ['b_0',['b',['../class_figura_geometrica.html#a25e5d6c21410103c25ec55c0117dac0d',1,'FiguraGeometrica::b'],['../class_leitura.html#aa0de441ab11e02a43c79905242119a8b',1,'Leitura::b'],['../struct_voxel.html#a5cd8432b1d7d0fd8b79e0fc7d10373a8',1,'Voxel::b'],['../class_sculptor.html#a7aafd7305ea634252d8288b60536cd96',1,'Sculptor::b']]]
];
