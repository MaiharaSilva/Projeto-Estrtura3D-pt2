var searchData=
[
  ['_7ecutbox_0',['~CutBox',['../class_cut_box.html#a66d4f54307d42a20c7ad8aa860ede5bf',1,'CutBox']]],
  ['_7ecutellipsoid_1',['~CutEllipsoid',['../class_cut_ellipsoid.html#a15c04713f9df8ba34d971fe946f728a5',1,'CutEllipsoid']]],
  ['_7ecutsphere_2',['~CutSphere',['../class_cut_sphere.html#a9314c0e7e18f0e488cce4d4b2fbb8ae7',1,'CutSphere']]],
  ['_7ecutvoxel_3',['~CutVoxel',['../class_cut_voxel.html#a7f5eb61ed9b3410a59e55e7815989a0b',1,'CutVoxel']]],
  ['_7efigurageometrica_4',['~FiguraGeometrica',['../class_figura_geometrica.html#a40ce7fb4b6cbf0cbe3852e342c739988',1,'FiguraGeometrica']]],
  ['_7eputbox_5',['~PutBox',['../class_put_box.html#a030fced5c7acc62c9842e480c5729f2e',1,'PutBox']]],
  ['_7eputellipsoid_6',['~PutEllipsoid',['../class_put_ellipsoid.html#a2a82dd453d32a966218d3bea49406872',1,'PutEllipsoid']]],
  ['_7eputsphere_7',['~PutSphere',['../class_put_sphere.html#ab1c65114a718e71349497588ccb3e04b',1,'PutSphere']]],
  ['_7eputvoxel_8',['~PutVoxel',['../class_put_voxel.html#ac3c14b19e69b462e3178b5dca92d7b34',1,'PutVoxel']]],
  ['_7esculptor_9',['~Sculptor',['../class_sculptor.html#a8f159bf97458326f16d2e238e11be7ff',1,'Sculptor']]]
];
