var searchData=
[
  ['sculptor_0',['Sculptor',['../class_sculptor.html#a0891937e4a9db84369e7922d3023aa67',1,'Sculptor']]],
  ['setcolor_1',['setColor',['../class_sculptor.html#a5b58ca5329e4e48cb87dc1335595d1a4',1,'Sculptor']]]
];
