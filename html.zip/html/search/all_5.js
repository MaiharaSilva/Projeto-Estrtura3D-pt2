var searchData=
[
  ['g_0',['g',['../class_figura_geometrica.html#a51930549bcb90d016b824f10f95df355',1,'FiguraGeometrica::g'],['../class_leitura.html#a3fecfee4d73022798dfd189d4e279ea3',1,'Leitura::g'],['../struct_voxel.html#a27c0da1ed2ff430401d23ff171612a73',1,'Voxel::g'],['../class_sculptor.html#a208c06af69a81a1568df4493868816f1',1,'Sculptor::g']]],
  ['getdx_1',['getDx',['../class_leitura.html#a3e9b1dada9159a90be3ebef94ca64fb1',1,'Leitura']]],
  ['getdy_2',['getDy',['../class_leitura.html#a6778bea12deb8b9313d1946ecb8dd820',1,'Leitura']]],
  ['getdz_3',['getDz',['../class_leitura.html#abb4380424dfbb78903515dd8e9221e82',1,'Leitura']]]
];
