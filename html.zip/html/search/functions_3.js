var searchData=
[
  ['leitura_0',['Leitura',['../class_leitura.html#a0546ea401044efc827074dad13867c61',1,'Leitura']]]
];
