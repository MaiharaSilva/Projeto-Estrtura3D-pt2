var searchData=
[
  ['draw_0',['draw',['../class_cut_box.html#a95d16d1e3164807a1f006614b753e205',1,'CutBox::draw()'],['../class_cut_ellipsoid.html#a3888e48949c6f89e1fe14bc3f95716fa',1,'CutEllipsoid::draw()'],['../class_cut_sphere.html#a8bde72ea67f248b4eec5435c695efcee',1,'CutSphere::draw()'],['../class_cut_voxel.html#a72bb583540f93f6f5345db1499417716',1,'CutVoxel::draw()'],['../class_figura_geometrica.html#a140c20d043bc6bfb4952a367d8ed6c1c',1,'FiguraGeometrica::draw()'],['../class_put_box.html#a58946137f1741c2c9b7a5bbcc229f5d8',1,'PutBox::draw()'],['../class_put_ellipsoid.html#a7563e424e3b7560c00c7cc2a3fc16425',1,'PutEllipsoid::draw()'],['../class_put_sphere.html#a2c3b27fe4f8041fa6c487b636b2ab017',1,'PutSphere::draw()'],['../class_put_voxel.html#a5bb3d4986a185b22ab050a41c7bb0017',1,'PutVoxel::draw()']]],
  ['dx_1',['dx',['../class_leitura.html#af79ad2cf005cf355d22b10ad10a92e65',1,'Leitura']]],
  ['dy_2',['dy',['../class_leitura.html#aed76ec62973d39c6290e54918cd141fc',1,'Leitura']]],
  ['dz_3',['dz',['../class_leitura.html#ad8c6dfc3041e5a3b91baf6b98a69bb2d',1,'Leitura']]]
];
