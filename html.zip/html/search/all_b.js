var searchData=
[
  ['r_0',['r',['../class_figura_geometrica.html#a0a4f57efb1a6c525c8aeee34c92e7eab',1,'FiguraGeometrica::r'],['../class_leitura.html#aa33c8f53eae2f13757d7e4be70ef491a',1,'Leitura::r'],['../struct_voxel.html#a06872ec79b836120b551a848968c0f1b',1,'Voxel::r'],['../class_sculptor.html#a3f5d2ec3b66d645019b8d81c810a1cd8',1,'Sculptor::r']]],
  ['radius_1',['radius',['../class_cut_sphere.html#a1952c3bad1eae06bff6776292381b4ed',1,'CutSphere::radius'],['../class_put_sphere.html#a3593cd1d907b6d249d1be8accd8a04de',1,'PutSphere::radius']]],
  ['rx_2',['rx',['../class_cut_ellipsoid.html#a5d2ee1baae0313b76621fb57c317c2f0',1,'CutEllipsoid::rx'],['../class_put_ellipsoid.html#a01c481bb5441245c5e8e879681899d56',1,'PutEllipsoid::rx']]],
  ['ry_3',['ry',['../class_cut_ellipsoid.html#a05d0bb0ec91e61d53d0b952bb8d733f2',1,'CutEllipsoid::ry'],['../class_put_ellipsoid.html#a4f4274c00346b59e57154b23df712bd4',1,'PutEllipsoid::ry']]],
  ['rz_4',['rz',['../class_cut_ellipsoid.html#aa47df0d08db6ae887e77b13ef142ade1',1,'CutEllipsoid::rz'],['../class_put_ellipsoid.html#aaf53d3f0093a1ab471f78da1c24a3606',1,'PutEllipsoid::rz']]]
];
