var searchData=
[
  ['sculptor_0',['Sculptor',['../class_sculptor.html',1,'Sculptor'],['../class_sculptor.html#a0891937e4a9db84369e7922d3023aa67',1,'Sculptor::Sculptor()']]],
  ['sculptor_2ecpp_1',['Sculptor.cpp',['../_sculptor_8cpp.html',1,'']]],
  ['sculptor_2eh_2',['Sculptor.h',['../_sculptor_8h.html',1,'']]],
  ['setcolor_3',['setColor',['../class_sculptor.html#a5b58ca5329e4e48cb87dc1335595d1a4',1,'Sculptor']]]
];
