var searchData=
[
  ['dx_0',['dx',['../class_leitura.html#af79ad2cf005cf355d22b10ad10a92e65',1,'Leitura']]],
  ['dy_1',['dy',['../class_leitura.html#aed76ec62973d39c6290e54918cd141fc',1,'Leitura']]],
  ['dz_2',['dz',['../class_leitura.html#ad8c6dfc3041e5a3b91baf6b98a69bb2d',1,'Leitura']]]
];
